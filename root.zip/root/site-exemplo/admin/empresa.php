<?php 
    $tituloPagina = "Empresa";
    include_once("inc/topo.php");
?>
<!-- Empresa - Início do código personalizado -->
<h1 class="h2">Empresa</h1>

<form>
    <div class="form-group">
    <textarea class="form-control" rows="13" cols="100" id="txtEmpresa" name="txtEmpresa"></textarea>
</div>
    <div class="form-group text-center">
    <button class="btn btn-primary">
        <span data-feather="save"></span>
        Salvar</button>
    </div>
</form>





<!-- Empresa - Final do código personalizado -->
<?php
    include_once("inc/rodape.php");
?>