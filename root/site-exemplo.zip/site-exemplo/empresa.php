<?php
    $tituloPagina = "Empresa";
    //Diretivas de Inclusão: include, include_once, require, require_once
    include_once("inc/topo.php");

?>
            <h1>Empresa</h1>
<p>Mussum Ipsum, cacilds vidis litro abertis. In elementis mé pra quem é amistosis quis leo. Sapien in monti palavris qui num significa nadis i pareci latim. Mé faiz elementum girarzis, nisi eros vermeio. Leite de capivaris, leite de mula manquis sem cabeça.</p>

<p>Quem num gosta di mé, boa gentis num é. Nullam volutpat risus nec leo commodo, ut interdum diam laoreet. Sed non consequat odio. Praesent vel viverra nisi. Mauris aliquet nunc non turpis scelerisque, eget. Suco de cevadiss deixa as pessoas mais interessantis.</p>

<p>Detraxit consequat et quo num tendi nada. Diuretics paradis num copo é motivis de denguis. A ordem dos tratores não altera o pão duris. Mais vale um bebadis conhecidiss, que um alcoolatra anonimis.</p>
<?php
    include_once("inc/rodape.php");
?>