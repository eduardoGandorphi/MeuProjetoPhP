<?php //categoria.model.php

    class Empresa {        
        public $Id;
        public $Titulo;
        public $Texto;
    }

?>

