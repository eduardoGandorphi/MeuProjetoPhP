<?php //usuario.model.php

    class Usuario {        
        public $Id;
        public $Nome;
        public $Email;
        public $Senha;
            
    }

?>

