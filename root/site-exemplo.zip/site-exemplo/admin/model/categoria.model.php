<?php //categoria.model.php

    class Categoria {        
        public $Id;
        public $Titulo;
            
    }

?>

