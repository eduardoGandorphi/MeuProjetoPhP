</main>
            <footer>
                <div>Copyright &copy; 2019 - Todos os Direitos Reservados</div>
                <div>Acesse nossas Redes Sociais</div>    
                <nav>
                   <ul>
                       <li><a href="index.php">Início</a></li> 
                       <li><a href="empresa.php">Empresa</a></li>
                        <li><a href="portfolio.php">Portfolio</a></li>
                        <li><a href="contato.php">Contato</a></li>
                    </ul>
                </nav>
            </footer>
        </div>
    </body>
</html>