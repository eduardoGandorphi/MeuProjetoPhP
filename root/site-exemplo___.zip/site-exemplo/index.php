<?php
    $tituloPagina = "Home";
    //Diretivas de Inclusão: include, include_once, require, require_once
    include_once("inc/topo.php");

?>
            <h1>Site Exemplo</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed elementum urna at leo imperdiet, id tristique odio hendrerit. Maecenas euismod justo lorem, ac dapibus nibh imperdiet id. Donec sed risus vitae dui fringilla interdum a pellentesque sem. Suspendisse sed consequat augue. Curabitur fermentum quam in lectus iaculis, eget consectetur est accumsan. Morbi quis consectetur lacus. Aliquam massa odio, interdum vulputate mi eget, euismod mattis orci. Vivamus feugiat lorem et massa tristique, eu hendrerit nulla lacinia. Duis convallis, felis in dapibus tristique, dui lectus volutpat ligula, in varius leo metus non orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nam quis libero ut lacus tincidunt iaculis vel sit amet est. Sed sit amet erat nisl. Nam tincidunt vitae felis nec ultrices.
</p>
<p>Nulla ultricies egestas massa, quis luctus nisi fermentum ornare. Mauris rutrum, ex id rhoncus tristique, nisl dui finibus justo, eu lobortis ipsum dolor in diam. Nullam placerat sapien accumsan tellus scelerisque lobortis. Nullam euismod pulvinar mauris, sit amet cursus ante pulvinar eu. Morbi tempor, turpis at sagittis lobortis, nisi est mattis nisi, nec porta ligula sapien at nibh. Nulla vitae scelerisque dui. Curabitur sed ex sed purus semper suscipit. Nulla auctor sit amet purus nec commodo. Aenean non mauris sed magna posuere lacinia. Integer rhoncus tincidunt iaculis. Morbi lacinia rhoncus interdum. Suspendisse ac aliquet metus, et vulputate ante.</p>
            
<?php
    include_once("inc/rodape.php");
?>


















