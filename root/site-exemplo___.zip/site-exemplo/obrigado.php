<?php
$tituloPagina = "Contato - Obrigado";
require_once("inc/topo.php");
?>
<h1>Contato Enviado - Obrigado!</h1>
<p>
Obrigado por entrar em contato conosco. Sua mensagem é muito importante para nós. 
</p>
<p>Em-breve retornaremos seu contato.</p>
<?php

require_once("inc/rodape.php");

?>