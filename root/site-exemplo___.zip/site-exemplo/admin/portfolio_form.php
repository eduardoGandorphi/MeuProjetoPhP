<?php 
    $tituloPagina = "Portfolio";
    include_once("inc/topo.php");
?>
<!-- Portfolio - Início do código personalizado -->
<h1 class="h2">Portfolio</h1>

<form>
    <div class="form-group">
        <label>Título</label>
        <input type="text" name="txtTitulo" id="txtTitulo" class="form-control" />
    </div>
    <div class="form-group">
        <label>Imagem</label>
        <input type="file" name="arqImagem" id="arqImagem" class="form-control" />
    </div>
    <div class="form-group">
        <label>Descrição</label>
        <textarea rows="5" name="txtDescricao" id="txtDescricao" class="form-control"></textarea>
    </div>
    <div class="form-group">
        <label>Link</label>
        <input type="url" name="txtLinkExterno" id="txtLinkExterno" class="form-control" />
    </div>
    <div class="form-group text-center">
        <button type="submit" class="btn btn-primary"><span data-feather="save"></span> Salvar</button>
    </div>
</form>

<!-- Portfolio - Final do código personalizado -->
<?php
    include_once("inc/rodape.php");
?>