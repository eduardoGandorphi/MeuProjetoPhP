<?php
    
    if($_POST["Email"] == "usuario@gmail.com" &&
       $_POST["Senha"] == "123") {
        
        session_start();
        $_SESSION["Usuario"] = $_POST["Email"];
        
        header("location: index.php");
        exit();
    }

    header("location: login.php?erro=Credenciais incorretas!");

?>