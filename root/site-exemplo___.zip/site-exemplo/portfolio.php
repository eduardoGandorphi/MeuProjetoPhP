<?php
    $tituloPagina = "Portfolio";
    //Diretivas de Inclusão: include, include_once, require, require_once
    include_once("inc/topo.php");

?>
            <h1>Portfolio</h1>
<div id="portfolio">
<div>
    <h3>Site da Pizzaria</h3>
    <img src="img/wireframe.png">
</div>

<div>
    <h3>Site da Sapataria</h3>
    <img src="img/wireframe.png">
</div>

<div>
    <h3>Site da Barbearia</h3>
    <img src="img/wireframe.png">
</div>

</div>
<?php
    include_once("inc/rodape.php");
?>